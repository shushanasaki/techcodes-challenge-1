# TechCodes 1/18 Intermediate challenge

Download this text file and get to working! GLHF.

# Stage 1
Begin with the input.txt file and a python file. The message `Hello, TechCodes Intermediate People!! Welcome to our challenge!!` is in that file, but oh no! each letter has been seperated from it's neighbor!
There is a random amount of random letters that aren't the character before each character, your job is to find those letters. Find the sum of the indicies where these letters occur.

# Stage 2
Using the number from **Stage 1**, find its prime factors. Continue to find the sum of these factors until the sum itself is prime. Use this sum.

# Stage 3
Given this number n from **Stage 2**, find the sum of the indicies of the first n occurences of n in the input file. Get the largest prime factor of this sum.

# Finishing
Once you have this final number, slowly and calmly walk (crazily run over to destroy your opponents) to Santiago or any of the other lame execs and tell them this number. If it is wrong, fix your code! The first person to get it right will win a hefty point value. Anyone who solves it after will get bragging rights.

Let's go yall.
